/*!
 * vue-admin-better
 * GitHub: https://github.com/zxwk1998/vue-admin-better
 * Gitee: https://gitee.com/chu1204505056/vue-admin-better
 *
 * 版权所有 (c) 2025 vue-admin-better
 * 本项目使用 MIT 许可证
 * 构建时间: 2026-4-29 04:16:42
 */
"use strict";
(self["rspackChunkvue_admin_better"] = self["rspackChunkvue_admin_better"] || []).push([[1027], {
93246: (function (module, __unused_rspack_exports, __webpack_require__) {
module.exports = __webpack_require__.p + "static/zfb_kf.95c922b4564cd764.jpg";

}),

}]);