/*!
 * vue-admin-better
 * GitHub: https://github.com/zxwk1998/vue-admin-better
 * Gitee: https://gitee.com/chu1204505056/vue-admin-better
 *
 * 版权所有 (c) 2025 vue-admin-better
 * 本项目使用 MIT 许可证
 * 构建时间: 2025-9-16 10:16:30
 */
(self["webpackChunkvue_admin_better"] = self["webpackChunkvue_admin_better"] || []).push([["6160"], {
69923: (function (module, __unused_webpack_exports, __webpack_require__) {
/**
 * @description 3个子配置，通用配置|主题配置|网络配置
 */
//默认配置
const {
  setting,
  theme,
  network
} = __webpack_require__(9260);
module.exports = Object.assign({}, setting, theme, network);

}),

}]);