"use strict";
(self["webpackChunkvue_admin_better"] = self["webpackChunkvue_admin_better"] || []).push([["6951"], {
2797: (function (module, __unused_webpack_exports, __webpack_require__) {
module.exports = __webpack_require__.p + "static/zfb_kf.95c922b4564cd764.jpg";

}),

}]);