"use strict";
(self["webpackChunkvue_admin_better"] = self["webpackChunkvue_admin_better"] || []).push([["2704"], {
32467: (function (module) {
module.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+CiAgPHBhdGggZmlsbD0ibm9uZSIgZD0iTTAgMGgyNHYyNEgweiIvPgogIDxwYXRoIGQ9Ik0xIDNoNGw3IDEyIDctMTJoNEwxMiAyMiAxIDN6bTguNjY3IDBMMTIgN2wyLjMzMy00aDQuMDM1TDEyIDE0IDUuNjMyIDNoNC4wMzV6Ii8+Cjwvc3ZnPgo=";

}),

}]);