/*!
 * vue-admin-better
 * GitHub: https://github.com/zxwk1998/vue-admin-better
 * Gitee: https://gitee.com/chu1204505056/vue-admin-better
 *
 * 版权所有 (c) 2025 vue-admin-better
 * 本项目使用 MIT 许可证
 * 构建时间: 2026-2-23 04:16:39
 */
"use strict";
(self["webpackChunkvue_admin_better"] = self["webpackChunkvue_admin_better"] || []).push([["3513"], {
18240: (function (module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var _node_modules_pnpm_css_loader_7_1_4_rspack_core_1_7_6_webpack_5_105_2_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0 = __webpack_require__(89778);
/* import */ var _node_modules_pnpm_css_loader_7_1_4_rspack_core_1_7_6_webpack_5_105_2_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_4_rspack_core_1_7_6_webpack_5_105_2_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0);
/* import */ var _node_modules_pnpm_css_loader_7_1_4_rspack_core_1_7_6_webpack_5_105_2_node_modules_css_loader_dist_runtime_api_js__rspack_import_1 = __webpack_require__(45627);
/* import */ var _node_modules_pnpm_css_loader_7_1_4_rspack_core_1_7_6_webpack_5_105_2_node_modules_css_loader_dist_runtime_api_js__rspack_import_1_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_4_rspack_core_1_7_6_webpack_5_105_2_node_modules_css_loader_dist_runtime_api_js__rspack_import_1);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_pnpm_css_loader_7_1_4_rspack_core_1_7_6_webpack_5_105_2_node_modules_css_loader_dist_runtime_api_js__rspack_import_1_default()((_node_modules_pnpm_css_loader_7_1_4_rspack_core_1_7_6_webpack_5_105_2_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0_default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".page-header{background:linear-gradient(135deg, #4d8af0 0%, #1a56db 100%);border-radius:12px;padding:30px;margin-bottom:24px;color:#fff;box-shadow:0 8px 32px rgba(102,126,234,.3)}.page-header .header-content{display:flex;justify-content:space-between;align-items:center}.page-header .header-content .header-left .page-title{font-size:2rem;font-weight:700;margin:0 0 8px 0;display:flex;align-items:center;gap:12px}.page-header .header-content .header-left .page-title .vab-icon{font-size:1.8rem}.page-header .header-content .header-left .page-description{font-size:1rem;opacity:.9;margin:0}.page-header .header-content .header-right{display:flex;align-items:center;gap:8px;font-size:1.1rem;font-weight:600}.page-header .header-content .header-right .vab-icon{font-size:1.3rem}", ""]);
// Exports
/* export default */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);


}),
61965: (function (module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var _node_modules_pnpm_css_loader_7_1_4_rspack_core_1_7_6_webpack_5_105_2_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0 = __webpack_require__(89778);
/* import */ var _node_modules_pnpm_css_loader_7_1_4_rspack_core_1_7_6_webpack_5_105_2_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_4_rspack_core_1_7_6_webpack_5_105_2_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0);
/* import */ var _node_modules_pnpm_css_loader_7_1_4_rspack_core_1_7_6_webpack_5_105_2_node_modules_css_loader_dist_runtime_api_js__rspack_import_1 = __webpack_require__(45627);
/* import */ var _node_modules_pnpm_css_loader_7_1_4_rspack_core_1_7_6_webpack_5_105_2_node_modules_css_loader_dist_runtime_api_js__rspack_import_1_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_4_rspack_core_1_7_6_webpack_5_105_2_node_modules_css_loader_dist_runtime_api_js__rspack_import_1);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_pnpm_css_loader_7_1_4_rspack_core_1_7_6_webpack_5_105_2_node_modules_css_loader_dist_runtime_api_js__rspack_import_1_default()((_node_modules_pnpm_css_loader_7_1_4_rspack_core_1_7_6_webpack_5_105_2_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0_default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".more-container .modern-card[data-v-64122919]{position:relative;border-radius:20px;overflow:hidden;background:#fff;box-shadow:0 8px 32px rgba(0,0,0,.08);height:100%}.more-container .modern-card .card-background[data-v-64122919]{position:absolute;top:0;left:0;right:0;bottom:0;overflow:hidden}.more-container .modern-card .card-background .bg-pattern[data-v-64122919]{position:absolute;top:-50%;left:-50%;width:200%;height:200%;background:radial-gradient(circle, rgba(255, 255, 255, 0.1) 1px, transparent 1px);background-size:20px 20px;transition:transform .4s ease}.more-container .modern-card .card-content[data-v-64122919]{position:relative;z-index:1;padding:32px;height:100%;display:flex;flex-direction:column}.more-container .modern-card .card-header[data-v-64122919]{display:flex;align-items:center;gap:16px;margin-bottom:24px}.more-container .modern-card .card-header .icon-wrapper[data-v-64122919]{width:64px;height:64px;border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:28px;color:#fff;box-shadow:0 8px 24px rgba(0,0,0,.15)}.more-container .modern-card .card-header .header-text[data-v-64122919]{flex:1}.more-container .modern-card .card-header .header-text .card-title[data-v-64122919]{margin:0 0 4px 0;font-size:24px;font-weight:700;color:#1a1a1a}.more-container .modern-card .card-header .header-text .card-subtitle[data-v-64122919]{font-size:14px;color:#666;font-weight:500}.more-container .modern-card .card-header .status-badge[data-v-64122919]{padding:6px 16px;border-radius:20px;font-size:12px;font-weight:600;color:#fff;text-transform:uppercase;letter-spacing:.5px}.more-container .modern-card .card-body[data-v-64122919]{flex:1;display:flex;flex-direction:column}.more-container .modern-card .card-footer[data-v-64122919]{margin-top:auto;padding-top:20px;border-top:1px solid rgba(0,0,0,.06)}.more-container .open-source .icon-wrapper[data-v-64122919]{background:linear-gradient(135deg, #4d8af0 0%, #1a56db 100%)}.more-container .open-source .status-badge[data-v-64122919]{background:linear-gradient(135deg, #67c23a 0%, #85ce61 100%)}.more-container .open-source .features-grid[data-v-64122919]{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:24px}.more-container .open-source .features-grid .feature-item[data-v-64122919]{display:flex;align-items:center;gap:12px;padding:12px;border-radius:12px;background:rgba(102,126,234,.05);transition:all .3s ease}.more-container .open-source .features-grid .feature-item[data-v-64122919]:hover{background:rgba(102,126,234,.1);transform:translateX(4px)}.more-container .open-source .features-grid .feature-item .feature-icon[data-v-64122919]{width:32px;height:32px;border-radius:8px;background:linear-gradient(135deg, #4d8af0 0%, #1a56db 100%);display:flex;align-items:center;justify-content:center;color:#fff;font-size:14px}.more-container .open-source .features-grid .feature-item span[data-v-64122919]{font-size:14px;font-weight:500;color:#333}.more-container .open-source .action-button[data-v-64122919]{display:inline-flex;align-items:center;gap:8px;padding:12px 24px;background:linear-gradient(135deg, #4d8af0 0%, #1a56db 100%);color:#fff;text-decoration:none;border-radius:12px;font-weight:600;transition:all .3s ease}.more-container .open-source .action-button[data-v-64122919]:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(102,126,234,.3)}.more-container .open-source .contact-info[data-v-64122919]{display:flex;align-items:center;gap:8px;margin-top:12px;font-size:14px;color:#666}.more-container .commercial .icon-wrapper[data-v-64122919]{background:linear-gradient(135deg, #f093fb 0%, #f5576c 100%)}.more-container .commercial .status-badge[data-v-64122919]{background:linear-gradient(135deg, #e6a23c 0%, #f7ba2a 100%)}.more-container .commercial .premium-products[data-v-64122919]{display:flex;flex-direction:column;gap:12px;margin-bottom:24px}.more-container .commercial .premium-products .product-card[data-v-64122919]{display:flex;align-items:center;padding:16px;border-radius:16px;background:linear-gradient(135deg, #4d8af0 0%, #1a56db 100%);color:#fff;text-decoration:none;transition:all .3s ease;position:relative;overflow:hidden}.more-container .commercial .premium-products .product-card[data-v-64122919]::before{content:\"\";position:absolute;top:0;left:-100%;width:100%;height:100%;background:linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);transition:left .5s ease}.more-container .commercial .premium-products .product-card[data-v-64122919]:hover{transform:translateX(8px);box-shadow:0 12px 32px rgba(102,126,234,.3)}.more-container .commercial .premium-products .product-card[data-v-64122919]:hover::before{left:100%}.more-container .commercial .premium-products .product-card.featured[data-v-64122919]{background:linear-gradient(135deg, #f093fb 0%, #f5576c 100%);box-shadow:0 8px 24px rgba(240,147,251,.3)}.more-container .commercial .premium-products .product-card.featured[data-v-64122919]:hover{box-shadow:0 12px 32px rgba(240,147,251,.4)}.more-container .commercial .premium-products .product-card .product-header[data-v-64122919]{display:flex;align-items:center;gap:8px;margin-right:16px}.more-container .commercial .premium-products .product-card .product-header .vab-icon[data-v-64122919]{font-size:20px}.more-container .commercial .premium-products .product-card .product-header .product-badge[data-v-64122919]{padding:2px 8px;border-radius:12px;font-size:10px;font-weight:600;background:rgba(255,255,255,.2);text-transform:uppercase}.more-container .commercial .premium-products .product-card .product-info[data-v-64122919]{flex:1}.more-container .commercial .premium-products .product-card .product-info .product-name[data-v-64122919]{font-size:16px;font-weight:600;margin-bottom:4px}.more-container .commercial .premium-products .product-card .product-info .product-price[data-v-64122919]{font-size:14px;opacity:.9}.more-container .commercial .premium-products .product-card .product-arrow[data-v-64122919]{opacity:0;transition:all .3s ease}.more-container .commercial .premium-products .product-card:hover .product-arrow[data-v-64122919]{opacity:1;transform:translateX(4px)}.more-container .commercial .service-info[data-v-64122919]{display:flex;align-items:center;gap:8px;font-size:14px;color:#666}.more-container .custom-service .service-header[data-v-64122919]{display:flex;align-items:center;gap:20px;margin-bottom:24px}.more-container .custom-service .service-header .service-icon[data-v-64122919]{width:64px;height:64px;border-radius:16px;background:linear-gradient(135deg, #e6a23c 0%, #f7ba2a 100%);display:flex;align-items:center;justify-content:center;font-size:28px;color:#fff;box-shadow:0 8px 24px rgba(230,162,60,.3)}.more-container .custom-service .service-header .service-info[data-v-64122919]{flex:1}.more-container .custom-service .service-header .service-info .service-title[data-v-64122919]{margin:0 0 8px 0;font-size:24px;font-weight:700;color:#1a1a1a}.more-container .custom-service .service-header .service-info .service-desc[data-v-64122919]{margin:0;font-size:14px;color:#666;line-height:1.5}.more-container .custom-service .service-header .service-price[data-v-64122919]{text-align:right}.more-container .custom-service .service-header .service-price .price-amount[data-v-64122919]{font-size:32px;font-weight:700;color:#e6a23c;line-height:1}.more-container .custom-service .service-header .service-price .price-note[data-v-64122919]{font-size:12px;color:#999;margin-top:4px}.more-container .custom-service .service-features[data-v-64122919]{display:grid;grid-template-columns:repeat(auto-fit, minmax(250px, 1fr));gap:16px}.more-container .custom-service .service-features .feature-item[data-v-64122919]{display:flex;align-items:center;gap:12px;padding:16px;border-radius:12px;background:rgba(230,162,60,.05);transition:all .3s ease}.more-container .custom-service .service-features .feature-item[data-v-64122919]:hover{background:rgba(230,162,60,.1);transform:translateY(-2px)}.more-container .custom-service .service-features .feature-item .vab-icon[data-v-64122919]{color:#e6a23c;font-size:18px}.more-container .custom-service .service-features .feature-item span[data-v-64122919]{font-size:14px;font-weight:500;color:#333}", ""]);
// Exports
/* export default */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);


}),
26528: (function (__unused_rspack_module, __webpack_exports__, __webpack_require__) {
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ VabPageHeader; }
});

;// CONCATENATED MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.28_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_80bad97972e2bc2f7eaa0c6060eb715f/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.28_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_80bad97972e2bc2f7eaa0c6060eb715f/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=template&id=2b14fb2d&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"page-header",class:_vm.customClass},[_c('div',{staticClass:"header-content"},[_c('div',{staticClass:"header-left"},[_c('h1',{staticClass:"page-title"},[(_vm.icon)?_c('vab-icon',{attrs:{"icon":_vm.icon}}):_vm._e(),_vm._v("\n        "+_vm._s(_vm.title)+"\n      ")],1),(_vm.description)?_c('p',{staticClass:"page-description",domProps:{"innerHTML":_vm._s(_vm.description)}}):_vm._e()]),(_vm.rightIcon || _vm.rightText)?_c('div',{staticClass:"header-right"},[_vm._t("right",function(){return [(_vm.rightIcon)?_c('vab-icon',{attrs:{"icon":_vm.rightIcon}}):_vm._e(),(_vm.rightText)?_c('span',[_vm._v(_vm._s(_vm.rightText))]):_vm._e()]})],2):_vm._e()])])}
var staticRenderFns = []


;// CONCATENATED MODULE: ./node_modules/.pnpm/babel-loader@10.0.0_@babel+core@7.29.0_webpack@5.105.2/node_modules/babel-loader/lib/index.js??clonedRuleSet-1[0].rules[0].use!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.28_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_80bad97972e2bc2f7eaa0c6060eb715f/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* export default */ var VabPageHeadervue_type_script_lang_js_ = ({
  name: 'VabPageHeader',
  props: {
    title: {
      type: String,
      required: true
    },
    description: {
      type: String,
      default: ''
    },
    icon: {
      type: Array,
      default: () => []
    },
    rightIcon: {
      type: Array,
      default: () => []
    },
    rightText: {
      type: String,
      default: ''
    },
    customClass: {
      type: String,
      default: ''
    }
  }
});
;// CONCATENATED MODULE: ./src/components/VabPageHeader/index.vue?vue&type=script&lang=js&
 /* export default */ var components_VabPageHeadervue_type_script_lang_js_ = (VabPageHeadervue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.2/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js
var injectStylesIntoStyleTag = __webpack_require__(64386);
var injectStylesIntoStyleTag_default = /*#__PURE__*/__webpack_require__.n(injectStylesIntoStyleTag);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.2/node_modules/style-loader/dist/runtime/styleDomAPI.js
var styleDomAPI = __webpack_require__(90499);
var styleDomAPI_default = /*#__PURE__*/__webpack_require__.n(styleDomAPI);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.2/node_modules/style-loader/dist/runtime/insertBySelector.js
var insertBySelector = __webpack_require__(43537);
var insertBySelector_default = /*#__PURE__*/__webpack_require__.n(insertBySelector);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.2/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js
var setAttributesWithoutAttributes = __webpack_require__(66778);
var setAttributesWithoutAttributes_default = /*#__PURE__*/__webpack_require__.n(setAttributesWithoutAttributes);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.2/node_modules/style-loader/dist/runtime/insertStyleElement.js
var insertStyleElement = __webpack_require__(56006);
var insertStyleElement_default = /*#__PURE__*/__webpack_require__.n(insertStyleElement);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.2/node_modules/style-loader/dist/runtime/styleTagTransform.js
var styleTagTransform = __webpack_require__(56571);
var styleTagTransform_default = /*#__PURE__*/__webpack_require__.n(styleTagTransform);
// EXTERNAL MODULE: ./node_modules/.pnpm/css-loader@7.1.4_@rspack+core@1.7.6_webpack@5.105.2/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.28_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_80bad97972e2bc2f7eaa0c6060eb715f/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.105.2/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.28_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_80bad97972e2bc2f7eaa0c6060eb715f/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=style&index=0&lang=scss&
var VabPageHeadervue_type_style_index_0_lang_scss_ = __webpack_require__(18240);
;// CONCATENATED MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.2/node_modules/style-loader/dist/cjs.js!./node_modules/.pnpm/css-loader@7.1.4_@rspack+core@1.7.6_webpack@5.105.2/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.28_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_80bad97972e2bc2f7eaa0c6060eb715f/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.105.2/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.28_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_80bad97972e2bc2f7eaa0c6060eb715f/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=style&index=0&lang=scss&

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (styleTagTransform_default());
options.setAttributes = (setAttributesWithoutAttributes_default());
options.insert = insertBySelector_default().bind(null, "head");
options.domAPI = (styleDomAPI_default());
options.insertStyleElement = (insertStyleElement_default());

var update = injectStylesIntoStyleTag_default()(VabPageHeadervue_type_style_index_0_lang_scss_["default"], options);




       /* export default */ var components_VabPageHeadervue_type_style_index_0_lang_scss_ = (VabPageHeadervue_type_style_index_0_lang_scss_["default"] && VabPageHeadervue_type_style_index_0_lang_scss_["default"].locals ? VabPageHeadervue_type_style_index_0_lang_scss_["default"].locals : undefined);

;// CONCATENATED MODULE: ./src/components/VabPageHeader/index.vue?vue&type=style&index=0&lang=scss&

// EXTERNAL MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.28_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_80bad97972e2bc2f7eaa0c6060eb715f/node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(23007);
;// CONCATENATED MODULE: ./src/components/VabPageHeader/index.vue



;


/* normalize component */

var component = (0,componentNormalizer["default"])(
  components_VabPageHeadervue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* export default */ var VabPageHeader = (component.exports);

}),
22368: (function (__unused_rspack_module, __webpack_exports__, __webpack_require__) {
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ more; }
});

;// CONCATENATED MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.28_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_80bad97972e2bc2f7eaa0c6060eb715f/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.28_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_80bad97972e2bc2f7eaa0c6060eb715f/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/vab/more/index.vue?vue&type=template&id=64122919&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"more-container"},[_c('vab-page-header',{attrs:{"description":"开源版本、商业版本和VIP群相关信息","icon":['fas', 'ellipsis-h'],"title":"更多功能"}}),_c('el-row',{attrs:{"gutter":24}},[_c('el-col',{attrs:{"lg":12,"md":24,"sm":24,"xl":12,"xs":24}},[_c('div',{staticClass:"modern-card open-source"},[_c('div',{staticClass:"card-background"},[_c('div',{staticClass:"bg-pattern"})]),_c('div',{staticClass:"card-content"},[_c('div',{staticClass:"card-header"},[_c('div',{staticClass:"icon-wrapper"},[_c('vab-icon',{attrs:{"icon":['fas', 'user']}})],1),_c('div',{staticClass:"header-text"},[_c('h3',{staticClass:"card-title"},[_vm._v("开源版本")]),_c('div',{staticClass:"card-subtitle"},[_vm._v("永久免费 · 个人/商业使用")])]),_c('div',{staticClass:"status-badge"},[_c('span',[_vm._v("免费")])])]),_c('div',{staticClass:"card-body"},[_c('div',{staticClass:"features-grid"},[_c('div',{staticClass:"feature-item"},[_c('div',{staticClass:"feature-icon"},[_c('vab-icon',{attrs:{"icon":['fas', 'check']}})],1),_c('span',[_vm._v("永久开源免费")])]),_c('div',{staticClass:"feature-item"},[_c('div',{staticClass:"feature-icon"},[_c('vab-icon',{attrs:{"icon":['fas', 'check']}})],1),_c('span',[_vm._v("支持横纵布局切换")])]),_c('div',{staticClass:"feature-item"},[_c('div',{staticClass:"feature-icon"},[_c('vab-icon',{attrs:{"icon":['fas', 'check']}})],1),_c('span',[_vm._v("保留控制台打印即可商用")])]),_c('div',{staticClass:"feature-item"},[_c('div',{staticClass:"feature-icon"},[_c('vab-icon',{attrs:{"icon":['fas', 'check']}})],1),_c('span',[_vm._v("作者信息可全部去除")])]),_c('div',{staticClass:"feature-item"},[_c('div',{staticClass:"feature-icon"},[_c('vab-icon',{attrs:{"icon":['fas', 'check']}})],1),_c('span',[_vm._v("包含打包优化教程")])]),_c('div',{staticClass:"feature-item"},[_c('div',{staticClass:"feature-icon"},[_c('vab-icon',{attrs:{"icon":['fas', 'check']}})],1),_c('span',[_vm._v("提供讨论群专属文档")])])]),_c('div',{staticClass:"card-footer"},[_c('a',{staticClass:"action-button",attrs:{"href":"https://github.com/zxwk1998/vue-admin-better","target":"_blank"}},[_c('vab-icon',{attrs:{"icon":['fab', 'github']}}),_c('span',[_vm._v("查看源码")])],1),_c('div',{staticClass:"contact-info"},[_c('vab-icon',{attrs:{"icon":['fab', 'qq']}}),_c('span',[_vm._v("QQ群：972435319、1139183756")])],1)])])])])]),_c('el-col',{attrs:{"lg":12,"md":24,"sm":24,"xl":12,"xs":24}},[_c('div',{staticClass:"modern-card commercial"},[_c('div',{staticClass:"card-background"},[_c('div',{staticClass:"bg-pattern"})]),_c('div',{staticClass:"card-content"},[_c('div',{staticClass:"card-header"},[_c('div',{staticClass:"icon-wrapper"},[_c('vab-icon',{attrs:{"icon":['fas', 'crown']}})],1),_c('div',{staticClass:"header-text"},[_c('h3',{staticClass:"card-title"},[_vm._v("商业版本")]),_c('div',{staticClass:"card-subtitle"},[_vm._v("专业级 · 企业级解决方案")])]),_c('div',{staticClass:"status-badge"},[_c('span',[_vm._v("PRO")])])]),_c('div',{staticClass:"card-body"},[_c('div',{staticClass:"premium-products"},[_c('a',{staticClass:"product-card",attrs:{"href":"https://vuejs-core.cn/admin-pro","target":"_blank"}},[_c('div',{staticClass:"product-header"},[_c('vab-icon',{attrs:{"icon":['fas', 'crown']}}),_c('div',{staticClass:"product-badge"},[_vm._v("PRO")])],1),_c('div',{staticClass:"product-info"},[_c('div',{staticClass:"product-name"},[_vm._v("Admin Pro")]),_c('div',{staticClass:"product-price"},[_vm._v("￥699")])]),_c('div',{staticClass:"product-arrow"},[_c('vab-icon',{attrs:{"icon":['fas', 'arrow-right']}})],1)]),_c('a',{staticClass:"product-card",attrs:{"href":"https://vuejs-core.cn/admin-plus","target":"_blank"}},[_c('div',{staticClass:"product-header"},[_c('vab-icon',{attrs:{"icon":['fas', 'gem']}}),_c('div',{staticClass:"product-badge"},[_vm._v("PLUS")])],1),_c('div',{staticClass:"product-info"},[_c('div',{staticClass:"product-name"},[_vm._v("Admin Plus")]),_c('div',{staticClass:"product-price"},[_vm._v("￥799")])]),_c('div',{staticClass:"product-arrow"},[_c('vab-icon',{attrs:{"icon":['fas', 'arrow-right']}})],1)]),_c('a',{staticClass:"product-card featured",attrs:{"href":"https://vuejs-core.cn/shop-vite","target":"_blank"}},[_c('div',{staticClass:"product-header"},[_c('vab-icon',{attrs:{"icon":['fas', 'shopping-cart']}}),_c('div',{staticClass:"product-badge"},[_vm._v("SHOP")])],1),_c('div',{staticClass:"product-info"},[_c('div',{staticClass:"product-name"},[_vm._v("Shop Vite")]),_c('div',{staticClass:"product-price"},[_vm._v("￥1899")])]),_c('div',{staticClass:"product-arrow"},[_c('vab-icon',{attrs:{"icon":['fas', 'arrow-right']}})],1)])]),_c('div',{staticClass:"card-footer"},[_c('div',{staticClass:"service-info"},[_c('vab-icon',{attrs:{"icon":['fas', 'star']}}),_c('span',[_vm._v("专业技术支持 · 源码授权 · 定制服务")])],1)])])])])])],1),_c('el-row',{staticStyle:{"margin-top":"24px"},attrs:{"gutter":24}},[_c('el-col',{attrs:{"span":24}},[_c('div',{staticClass:"modern-card custom-service"},[_c('div',{staticClass:"card-background"},[_c('div',{staticClass:"bg-pattern"})]),_c('div',{staticClass:"card-content"},[_c('div',{staticClass:"service-header"},[_c('div',{staticClass:"service-icon"},[_c('vab-icon',{attrs:{"icon":['fas', 'paint-brush']}})],1),_c('div',{staticClass:"service-info"},[_c('h3',{staticClass:"service-title"},[_vm._v("自定义版权服务")]),_c('p',{staticClass:"service-desc"},[_vm._v("如需自定义版权及作者信息，可联系微信客服zxwk-bfq购买")])]),_c('div',{staticClass:"service-price"},[_c('div',{staticClass:"price-amount"},[_vm._v("￥99")]),_c('div',{staticClass:"price-note"},[_vm._v("自愿原则")])])]),_c('div',{staticClass:"service-features"},[_c('div',{staticClass:"feature-item"},[_c('vab-icon',{attrs:{"icon":['fas', 'check-circle']}}),_c('span',[_vm._v("移除所有作者信息")])],1),_c('div',{staticClass:"feature-item"},[_c('vab-icon',{attrs:{"icon":['fas', 'check-circle']}}),_c('span',[_vm._v("自定义版权声明")])],1),_c('div',{staticClass:"feature-item"},[_c('vab-icon',{attrs:{"icon":['fas', 'check-circle']}}),_c('span',[_vm._v("品牌化定制")])],1),_c('div',{staticClass:"feature-item"},[_c('vab-icon',{attrs:{"icon":['fas', 'check-circle']}}),_c('span',[_vm._v("自愿原则")])],1)])])])])],1)],1)}
var staticRenderFns = []


// EXTERNAL MODULE: ./src/components/VabPageHeader/index.vue + 5 modules
var VabPageHeader = __webpack_require__(26528);
;// CONCATENATED MODULE: ./node_modules/.pnpm/babel-loader@10.0.0_@babel+core@7.29.0_webpack@5.105.2/node_modules/babel-loader/lib/index.js??clonedRuleSet-1[0].rules[0].use!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.28_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_80bad97972e2bc2f7eaa0c6060eb715f/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/vab/more/index.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* export default */ var morevue_type_script_lang_js_ = ({
  name: 'More',
  components: {
    VabPageHeader: VabPageHeader["default"]
  },
  data() {
    return {
      nodeEnv: "production"
    };
  },
  created() {},
  mounted() {},
  methods: {}
});
;// CONCATENATED MODULE: ./src/views/vab/more/index.vue?vue&type=script&lang=js&
 /* export default */ var vab_morevue_type_script_lang_js_ = (morevue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.2/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js
var injectStylesIntoStyleTag = __webpack_require__(64386);
var injectStylesIntoStyleTag_default = /*#__PURE__*/__webpack_require__.n(injectStylesIntoStyleTag);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.2/node_modules/style-loader/dist/runtime/styleDomAPI.js
var styleDomAPI = __webpack_require__(90499);
var styleDomAPI_default = /*#__PURE__*/__webpack_require__.n(styleDomAPI);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.2/node_modules/style-loader/dist/runtime/insertBySelector.js
var insertBySelector = __webpack_require__(43537);
var insertBySelector_default = /*#__PURE__*/__webpack_require__.n(insertBySelector);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.2/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js
var setAttributesWithoutAttributes = __webpack_require__(66778);
var setAttributesWithoutAttributes_default = /*#__PURE__*/__webpack_require__.n(setAttributesWithoutAttributes);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.2/node_modules/style-loader/dist/runtime/insertStyleElement.js
var insertStyleElement = __webpack_require__(56006);
var insertStyleElement_default = /*#__PURE__*/__webpack_require__.n(insertStyleElement);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.2/node_modules/style-loader/dist/runtime/styleTagTransform.js
var styleTagTransform = __webpack_require__(56571);
var styleTagTransform_default = /*#__PURE__*/__webpack_require__.n(styleTagTransform);
// EXTERNAL MODULE: ./node_modules/.pnpm/css-loader@7.1.4_@rspack+core@1.7.6_webpack@5.105.2/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.28_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_80bad97972e2bc2f7eaa0c6060eb715f/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.105.2/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.28_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_80bad97972e2bc2f7eaa0c6060eb715f/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/vab/more/index.vue?vue&type=style&index=0&id=64122919&lang=scss&scoped=true&
var morevue_type_style_index_0_id_64122919_lang_scss_scoped_true_ = __webpack_require__(61965);
;// CONCATENATED MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.2/node_modules/style-loader/dist/cjs.js!./node_modules/.pnpm/css-loader@7.1.4_@rspack+core@1.7.6_webpack@5.105.2/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.28_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_80bad97972e2bc2f7eaa0c6060eb715f/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.105.2/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.28_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_80bad97972e2bc2f7eaa0c6060eb715f/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/vab/more/index.vue?vue&type=style&index=0&id=64122919&lang=scss&scoped=true&

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (styleTagTransform_default());
options.setAttributes = (setAttributesWithoutAttributes_default());
options.insert = insertBySelector_default().bind(null, "head");
options.domAPI = (styleDomAPI_default());
options.insertStyleElement = (insertStyleElement_default());

var update = injectStylesIntoStyleTag_default()(morevue_type_style_index_0_id_64122919_lang_scss_scoped_true_["default"], options);




       /* export default */ var vab_morevue_type_style_index_0_id_64122919_lang_scss_scoped_true_ = (morevue_type_style_index_0_id_64122919_lang_scss_scoped_true_["default"] && morevue_type_style_index_0_id_64122919_lang_scss_scoped_true_["default"].locals ? morevue_type_style_index_0_id_64122919_lang_scss_scoped_true_["default"].locals : undefined);

;// CONCATENATED MODULE: ./src/views/vab/more/index.vue?vue&type=style&index=0&id=64122919&lang=scss&scoped=true&

// EXTERNAL MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.28_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_80bad97972e2bc2f7eaa0c6060eb715f/node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(23007);
;// CONCATENATED MODULE: ./src/views/vab/more/index.vue



;


/* normalize component */

var component = (0,componentNormalizer["default"])(
  vab_morevue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  "64122919",
  null
  
)

/* export default */ var more = (component.exports);

}),

}]);